# ==============================================================
# File generated on Mon Feb 04 19:42:58 +0800 2019
# Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
# SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
# IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
# Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
# ==============================================================
add_files -tb ../src/image_orb_tb.cpp -cflags { -Wno-unknown-pragmas}
add_files hls_image_orb/src/image_orb.h
add_files hls_image_orb/src/image_orb.cpp
add_files hls_image_orb/src/image.bmp
set_part xc7z010clg400-1
create_clock -name default -period 10
config_export -format=ip_catalog
config_export -rtl=verilog
