############################################################
## This file is generated automatically by Vivado HLS.
## Please DO NOT edit it.
## Copyright (C) 1986-2018 Xilinx, Inc. All Rights Reserved.
############################################################
open_project hls_image_orb
set_top image_sobel
add_files hls_image_orb/src/image_orb.h
add_files hls_image_orb/src/image_orb.cpp
add_files hls_image_orb/src/image.bmp
add_files -tb hls_image_orb/src/image_orb_tb.cpp -cflags "-Wno-unknown-pragmas"
open_solution "solution1"
set_part {xc7z010clg400-1} -tool vivado
create_clock -period 10 -name default
config_export -format ip_catalog -rtl verilog
#source "./hls_image_orb/solution1/directives.tcl"
csim_design
csynth_design
cosim_design
export_design -rtl verilog -format ip_catalog
