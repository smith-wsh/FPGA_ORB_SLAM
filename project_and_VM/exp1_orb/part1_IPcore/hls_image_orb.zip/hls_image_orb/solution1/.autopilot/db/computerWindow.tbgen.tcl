set moduleName computerWindow
set isTaskLevelControl 1
set isCombinational 0
set isDatapathOnly 1
set isPipelined 1
set pipeline_type function
set FunctionProtocol ap_ctrl_hs
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set C_modelName {computerWindow}
set C_modelType { int 1 }
set C_modelArgList {
	{ window_val_0_2_rea int 32 regular  }
	{ window_val_0_3_rea int 32 regular  }
	{ window_val_0_4_rea int 32 regular  }
	{ window_val_1_1_rea int 32 regular  }
	{ window_val_1_5_rea int 32 regular  }
	{ window_val_2_0_rea int 32 regular  }
	{ window_val_2_6_rea int 32 regular  }
	{ window_val_3_0_rea int 32 regular  }
	{ window_val_3_3_rea int 32 regular  }
	{ window_val_3_6_rea int 32 regular  }
	{ window_val_4_0_rea int 32 regular  }
	{ window_val_4_6_rea int 32 regular  }
	{ window_val_5_1_rea int 24 regular  }
	{ window_val_5_5_rea int 24 regular  }
	{ window_val_6_2_rea int 24 regular  }
	{ window_val_6_3_rea int 24 regular  }
	{ window_val_6_4_rea int 24 regular  }
	{ threshold_data int 9 regular  }
}
set C_modelArgMapList {[ 
	{ "Name" : "window_val_0_2_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_0_3_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_0_4_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_1_1_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_1_5_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_2_0_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_2_6_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_3_0_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_3_3_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_3_6_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_4_0_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_4_6_rea", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_5_1_rea", "interface" : "wire", "bitwidth" : 24, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_5_5_rea", "interface" : "wire", "bitwidth" : 24, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_6_2_rea", "interface" : "wire", "bitwidth" : 24, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_6_3_rea", "interface" : "wire", "bitwidth" : 24, "direction" : "READONLY"} , 
 	{ "Name" : "window_val_6_4_rea", "interface" : "wire", "bitwidth" : 24, "direction" : "READONLY"} , 
 	{ "Name" : "threshold_data", "interface" : "wire", "bitwidth" : 9, "direction" : "READONLY"} , 
 	{ "Name" : "ap_return", "interface" : "wire", "bitwidth" : 1} ]}
# RTL Port declarations: 
set portNum 22
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ window_val_0_2_rea sc_in sc_lv 32 signal 0 } 
	{ window_val_0_3_rea sc_in sc_lv 32 signal 1 } 
	{ window_val_0_4_rea sc_in sc_lv 32 signal 2 } 
	{ window_val_1_1_rea sc_in sc_lv 32 signal 3 } 
	{ window_val_1_5_rea sc_in sc_lv 32 signal 4 } 
	{ window_val_2_0_rea sc_in sc_lv 32 signal 5 } 
	{ window_val_2_6_rea sc_in sc_lv 32 signal 6 } 
	{ window_val_3_0_rea sc_in sc_lv 32 signal 7 } 
	{ window_val_3_3_rea sc_in sc_lv 32 signal 8 } 
	{ window_val_3_6_rea sc_in sc_lv 32 signal 9 } 
	{ window_val_4_0_rea sc_in sc_lv 32 signal 10 } 
	{ window_val_4_6_rea sc_in sc_lv 32 signal 11 } 
	{ window_val_5_1_rea sc_in sc_lv 24 signal 12 } 
	{ window_val_5_5_rea sc_in sc_lv 24 signal 13 } 
	{ window_val_6_2_rea sc_in sc_lv 24 signal 14 } 
	{ window_val_6_3_rea sc_in sc_lv 24 signal 15 } 
	{ window_val_6_4_rea sc_in sc_lv 24 signal 16 } 
	{ threshold_data sc_in sc_lv 9 signal 17 } 
	{ ap_return sc_out sc_lv 1 signal -1 } 
	{ ap_ce sc_in sc_logic 1 ce -1 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "window_val_0_2_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_0_2_rea", "role": "default" }} , 
 	{ "name": "window_val_0_3_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_0_3_rea", "role": "default" }} , 
 	{ "name": "window_val_0_4_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_0_4_rea", "role": "default" }} , 
 	{ "name": "window_val_1_1_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_1_1_rea", "role": "default" }} , 
 	{ "name": "window_val_1_5_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_1_5_rea", "role": "default" }} , 
 	{ "name": "window_val_2_0_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_2_0_rea", "role": "default" }} , 
 	{ "name": "window_val_2_6_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_2_6_rea", "role": "default" }} , 
 	{ "name": "window_val_3_0_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_3_0_rea", "role": "default" }} , 
 	{ "name": "window_val_3_3_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_3_3_rea", "role": "default" }} , 
 	{ "name": "window_val_3_6_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_3_6_rea", "role": "default" }} , 
 	{ "name": "window_val_4_0_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_4_0_rea", "role": "default" }} , 
 	{ "name": "window_val_4_6_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "window_val_4_6_rea", "role": "default" }} , 
 	{ "name": "window_val_5_1_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":24, "type": "signal", "bundle":{"name": "window_val_5_1_rea", "role": "default" }} , 
 	{ "name": "window_val_5_5_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":24, "type": "signal", "bundle":{"name": "window_val_5_5_rea", "role": "default" }} , 
 	{ "name": "window_val_6_2_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":24, "type": "signal", "bundle":{"name": "window_val_6_2_rea", "role": "default" }} , 
 	{ "name": "window_val_6_3_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":24, "type": "signal", "bundle":{"name": "window_val_6_3_rea", "role": "default" }} , 
 	{ "name": "window_val_6_4_rea", "direction": "in", "datatype": "sc_lv", "bitwidth":24, "type": "signal", "bundle":{"name": "window_val_6_4_rea", "role": "default" }} , 
 	{ "name": "threshold_data", "direction": "in", "datatype": "sc_lv", "bitwidth":9, "type": "signal", "bundle":{"name": "threshold_data", "role": "default" }} , 
 	{ "name": "ap_return", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "ap_return", "role": "default" }} , 
 	{ "name": "ap_ce", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "ce", "bundle":{"name": "ap_ce", "role": "default" }}  ]}

set RtlHierarchyInfo {[
	{"ID" : "0", "Level" : "0", "Path" : "`AUTOTB_DUT_INST", "Parent" : "", "Child" : ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34"],
		"CDFG" : "computerWindow",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "7", "EstimateLatencyMin" : "7", "EstimateLatencyMax" : "7",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "window_val_0_2_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_0_3_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_0_4_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_1_1_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_1_5_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_2_0_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_2_6_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_3_0_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_3_3_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_3_6_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_4_0_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_4_6_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_5_1_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_5_5_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_6_2_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_6_3_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "window_val_6_4_rea", "Type" : "None", "Direction" : "I"},
			{"Name" : "threshold_data", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "1", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U1", "Parent" : "0"},
	{"ID" : "2", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U2", "Parent" : "0"},
	{"ID" : "3", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U3", "Parent" : "0"},
	{"ID" : "4", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U4", "Parent" : "0"},
	{"ID" : "5", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U5", "Parent" : "0"},
	{"ID" : "6", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U6", "Parent" : "0"},
	{"ID" : "7", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U7", "Parent" : "0"},
	{"ID" : "8", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U8", "Parent" : "0"},
	{"ID" : "9", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U9", "Parent" : "0"},
	{"ID" : "10", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U10", "Parent" : "0"},
	{"ID" : "11", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mdEe_U11", "Parent" : "0"},
	{"ID" : "12", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_meOg_U12", "Parent" : "0"},
	{"ID" : "13", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U13", "Parent" : "0"},
	{"ID" : "14", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U14", "Parent" : "0"},
	{"ID" : "15", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U15", "Parent" : "0"},
	{"ID" : "16", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U16", "Parent" : "0"},
	{"ID" : "17", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U17", "Parent" : "0"},
	{"ID" : "18", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U18", "Parent" : "0"},
	{"ID" : "19", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U19", "Parent" : "0"},
	{"ID" : "20", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U20", "Parent" : "0"},
	{"ID" : "21", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U21", "Parent" : "0"},
	{"ID" : "22", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U22", "Parent" : "0"},
	{"ID" : "23", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U23", "Parent" : "0"},
	{"ID" : "24", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U24", "Parent" : "0"},
	{"ID" : "25", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U25", "Parent" : "0"},
	{"ID" : "26", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U26", "Parent" : "0"},
	{"ID" : "27", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U27", "Parent" : "0"},
	{"ID" : "28", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U28", "Parent" : "0"},
	{"ID" : "29", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U29", "Parent" : "0"},
	{"ID" : "30", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U30", "Parent" : "0"},
	{"ID" : "31", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U31", "Parent" : "0"},
	{"ID" : "32", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U32", "Parent" : "0"},
	{"ID" : "33", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mbkb_U33", "Parent" : "0"},
	{"ID" : "34", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.image_sobel_mac_mcud_U34", "Parent" : "0"}]}


set ArgLastReadFirstWriteLatency {
	computerWindow {
		window_val_0_2_rea {Type I LastRead 0 FirstWrite -1}
		window_val_0_3_rea {Type I LastRead 0 FirstWrite -1}
		window_val_0_4_rea {Type I LastRead 0 FirstWrite -1}
		window_val_1_1_rea {Type I LastRead 0 FirstWrite -1}
		window_val_1_5_rea {Type I LastRead 0 FirstWrite -1}
		window_val_2_0_rea {Type I LastRead 0 FirstWrite -1}
		window_val_2_6_rea {Type I LastRead 0 FirstWrite -1}
		window_val_3_0_rea {Type I LastRead 0 FirstWrite -1}
		window_val_3_3_rea {Type I LastRead 0 FirstWrite -1}
		window_val_3_6_rea {Type I LastRead 0 FirstWrite -1}
		window_val_4_0_rea {Type I LastRead 0 FirstWrite -1}
		window_val_4_6_rea {Type I LastRead 0 FirstWrite -1}
		window_val_5_1_rea {Type I LastRead 0 FirstWrite -1}
		window_val_5_5_rea {Type I LastRead 0 FirstWrite -1}
		window_val_6_2_rea {Type I LastRead 0 FirstWrite -1}
		window_val_6_3_rea {Type I LastRead 0 FirstWrite -1}
		window_val_6_4_rea {Type I LastRead 0 FirstWrite -1}
		threshold_data {Type I LastRead 0 FirstWrite -1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "7", "Max" : "7"}
	, {"Name" : "Interval", "Min" : "1", "Max" : "1"}
]}

set PipelineEnableSignalInfo {[
]}

set Spec2ImplPortList { 
	window_val_0_2_rea { ap_none {  { window_val_0_2_rea in_data 0 32 } } }
	window_val_0_3_rea { ap_none {  { window_val_0_3_rea in_data 0 32 } } }
	window_val_0_4_rea { ap_none {  { window_val_0_4_rea in_data 0 32 } } }
	window_val_1_1_rea { ap_none {  { window_val_1_1_rea in_data 0 32 } } }
	window_val_1_5_rea { ap_none {  { window_val_1_5_rea in_data 0 32 } } }
	window_val_2_0_rea { ap_none {  { window_val_2_0_rea in_data 0 32 } } }
	window_val_2_6_rea { ap_none {  { window_val_2_6_rea in_data 0 32 } } }
	window_val_3_0_rea { ap_none {  { window_val_3_0_rea in_data 0 32 } } }
	window_val_3_3_rea { ap_none {  { window_val_3_3_rea in_data 0 32 } } }
	window_val_3_6_rea { ap_none {  { window_val_3_6_rea in_data 0 32 } } }
	window_val_4_0_rea { ap_none {  { window_val_4_0_rea in_data 0 32 } } }
	window_val_4_6_rea { ap_none {  { window_val_4_6_rea in_data 0 32 } } }
	window_val_5_1_rea { ap_none {  { window_val_5_1_rea in_data 0 24 } } }
	window_val_5_5_rea { ap_none {  { window_val_5_5_rea in_data 0 24 } } }
	window_val_6_2_rea { ap_none {  { window_val_6_2_rea in_data 0 24 } } }
	window_val_6_3_rea { ap_none {  { window_val_6_3_rea in_data 0 24 } } }
	window_val_6_4_rea { ap_none {  { window_val_6_4_rea in_data 0 24 } } }
	threshold_data { ap_none {  { threshold_data in_data 0 9 } } }
}
