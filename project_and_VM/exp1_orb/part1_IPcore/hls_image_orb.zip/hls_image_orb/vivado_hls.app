<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="com.autoesl.autopilot.project" name="hls_image_orb" top="image_sobel">
  <files>
    <file name="../src/image_orb_tb.cpp" sc="0" tb="1" cflags=" -Wno-unknown-pragmas"/>
    <file name="hls_image_orb/src/image_orb.h" sc="0" tb="false" cflags=""/>
    <file name="hls_image_orb/src/image_orb.cpp" sc="0" tb="false" cflags=""/>
    <file name="hls_image_orb/src/image.bmp" sc="0" tb="false" cflags=""/>
  </files>
  <solutions>
    <solution name="solution1" status="active"/>
  </solutions>
  <includePaths/>
  <libraryPaths/>
  <Simulation>
    <SimFlow name="csim" csimMode="2" lastCsimMode="2"/>
  </Simulation>
</project>
